<?php

namespace App\Presenters;

use App\Components\TodoEditForm\TodoEditForm;
use App\Components\TodoEditForm\TodoEditFormFactory;
use App\Model\Facades\TodosFacade;
use Nette\Application\UI\Presenter;

/**
 * Class TodoPresenter
 * @package App\Presenters
 */
class TodoPresenter extends Presenter{
  private TodosFacade $todosFacade;
  private TodoEditFormFactory $todoEditFormFactory;

  /**
   * Akce pro výpis úkolů
   */
  public function renderDefault():void {
    //TODO tady to bude chtít v rámci plnění úkolů na cvičení nějaké změny
    $this->template->todos = $this->todosFacade->findTodos();
  }

  /**
   * Akce pro úpravu úkolu
   * @param int $id
   * @throws \Nette\Application\AbortException
   */
  public function actionEdit(int $id):void {
    try{
      $todo = $this->todosFacade->getTodo($id);
    }catch (\Exception $e){
      $this->flashMessage('Úkol už tu není','error');
      $this->redirect('default');
    }

    $form = $this->getComponent('todoEditForm');
    $form->setDefaults($todo);
  }

  /**
   * Komponenta pro vytváření a editaci úkolů
   * @return TodoEditForm
   */
  protected function createComponentTodoEditForm():TodoEditForm {
    $form = $this->todoEditFormFactory->create();
    $form->onCancel[]=function(){
      $this->redirect('default');
    };
    $form->onFinished[]=function($message=''){
      if ($message){
        $this->flashMessage($message);
      }
      $this->redirect('default');
    };
    $form->onFailed()[]=function($message=''){
      if ($message){
        $this->flashMessage($message,'error');
      }
      $this->redirect('default');
    };
    return $form;
  }

  public function injectTodosFacade(TodosFacade $todosFacade):void {
    $this->todosFacade=$todosFacade;
  }

  public function injectTodoEditFormFactory(TodoEditFormFactory $todoEditFormFactory){
    $this->todoEditFormFactory=$todoEditFormFactory;
  }
}