<?php

namespace App\Presenters;

use App\Components\TodoEditForm\TodoEditForm;
use App\Components\TodoEditForm\TodoEditFormFactory;
use App\Model\Facades\TagsFacade;
use App\Model\Facades\TodosFacade;
use Nette\Application\UI\Presenter;
use Nette\Utils\Paginator;

/**
 * Class TodoPresenter
 * @package App\Presenters
 */
class TodoPresenter extends Presenter{
  /** @var TodosFacade $todosFacade*/
  private $todosFacade;
  /** @var TagsFacade $tagsFacade */
  private $tagsFacade;
  /** @var TodoEditFormFactory $todoEditFormFactory */
  private $todoEditFormFactory;

  /** @persistent */
  public $tag = null;
  /** @persistent */
  public $page = 1;

  /**
   * Akce pro výpis úkolů
   * @throws \Nette\Application\AbortException
   */
  public function renderDefault(){
    $activeTag = null;
    if ($this->tag){
      try{
        $activeTag=$this->tagsFacade->getTag((int)$this->tag);
      }catch (\Exception $e){
        $this->redirect('default',['tag'=>null,'page'=>1]);
      }
    }

    $this->template->activeTag=$activeTag;
    $this->template->tags=$this->tagsFacade->findTags();

    #region připravení paginatoru
    $paginator = new Paginator();
    $paginator->setItemCount($this->todosFacade->findTodosCount($activeTag));
    $paginator->setItemsPerPage(10);//počet položek na stránku - to by mohla být konstanta, nebo také další persistent proměnná :)

    $currentPage = min($this->page, $paginator->pageCount);//nechceme vyšší číslo, než je počet stránek
    $currentPage = max($currentPage, 1);//nechceme zápornou stránku
    if ($currentPage != $this->page){
      $this->redirect('default',['page'=>$currentPage]);
    }
    
    $paginator->setPage($currentPage); //aktuální stránku předáme do paginátoru
    #endregion

    //načtení úkolů
    $this->template->todos = $this->todosFacade->findTodos($activeTag, null, $paginator->offset, $paginator->itemsPerPage);
    $this->template->paginator = $paginator;
  }

  /**
   * Akce pro úpravu úkolu
   * @param int $id
   * @throws \Nette\Application\AbortException
   */
  public function actionEdit(int $id){
    try{
      $todo = $this->todosFacade->getTodo($id);
    }catch (\Exception $e){
      $this->flashMessage('Úkol už tu není','error');
      $this->redirect('default');
    }

    $form = $this->getComponent('todoEditForm');
    $form->setDefaults($todo);
  }

  /**
   * Signál pro změnu stavu úkolu
   * @param int $id
   * @param bool $completed = true
   * @throws \Nette\Application\AbortException
   */
  public function handleCompleted(int $id, bool $completed=true){
    try{
      $todo = $this->todosFacade->getTodo($id);
    }catch (\Exception $e){
      $this->flashMessage('Úkol už tu není','error');
      $this->redirect('this');
    }

    if ($completed!=$todo->completed){
      $todo->completed=$completed;
      if ($this->todosFacade->saveTodo($todo)){
        $this->flashMessage('Stav úkolu byl změněn.');
      }
    }

    $this->redirect('this');
  }

  /**
   * Komponenta pro vytváření a editaci úkolů
   * @return TodoEditForm
   */
  protected function createComponentTodoEditForm():TodoEditForm {
    $form = $this->todoEditFormFactory->create();
    $form->onCancel[]=function(){
      $this->redirect('default');
    };
    $form->onFinished[]=function($message=''){
      if ($message){
        $this->flashMessage($message);
      }
      $this->redirect('default');
    };
    $form->onFailed()[]=function($message=''){
      if ($message){
        $this->flashMessage($message,'error');
      }
      $this->redirect('default');
    };
    return $form;
  }

  public function injectTodosFacade(TodosFacade $todosFacade){
    $this->todosFacade=$todosFacade;
  }

  public function injectTagsFacade(TagsFacade $tagsFacade){
    $this->tagsFacade=$tagsFacade;
  }

  public function injectTodoEditFormFactory(TodoEditFormFactory $todoEditFormFactory){
    $this->todoEditFormFactory=$todoEditFormFactory;
  }
}