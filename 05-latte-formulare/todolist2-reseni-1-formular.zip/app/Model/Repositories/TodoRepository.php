<?php

namespace App\Model\Repositories;

/**
 * Class TodoRepository - repozitář pro ukládání jednotlivých úkolů
 * @package App\Model\Repositories
 */
class TodoRepository extends BaseRepository{

}