<?php

namespace App\Components\TodoEditForm;

use App\Model\Entities\Todo;
use App\Model\Facades\TodosFacade;
use Nette;
use Nette\Application\UI\Form;
use Nette\SmartObject;

/**
 * Class TodoEditForm
 * @package App\Components\TodoEditForm
 *
 * @method onFinished(string $message = '')
 * @method onFailed(string $message = '')
 * @method onCancel()
 */
class TodoEditForm extends Form{

  use SmartObject;

  /** @var callable[] $onFinished */
  public array $onFinished = [];
  /** @var callable[] $onFailed */
  public array $onFailed = [];
  /** @var callable[] $onCancel */
  public array $onCancel = [];
  private TodosFacade $todosFacade;

  public function __construct(TodosFacade $todosFacade,Nette\ComponentModel\IContainer $parent = null, string $name = null){
    parent::__construct($parent, $name);
    $this->todosFacade=$todosFacade;
    $this->createSubcomponents();
  }

  private function createSubcomponents():void {
    $todoId=$this->addHidden('todoId');
    $this->addText('title','Název úkolu:')
      ->setRequired('Vyplňte název úkolu');
    $this->addTextArea('description','Popis:')
      ->setRequired(false);
    $this->addSubmit('save','uložit')->onClick[]=function(){
      $values = $this->getValues('array');
      if (!empty($values['todoId'])){
        //mám zadané ID úkolu
        try{
          $todo = $this->todosFacade->getTodo($values['todoId']);
        }catch (\Exception $e){
          $this->onFailed('úkol nebyl nalezen');
          return;
        }
      }else{
        $todo=new Todo();
      }
      $todo->title=$values['title'];
      $todo->description=$values['description'];
      $this->todosFacade->saveTodo($todo);
      $this->setValues(['todoId'=>$todo->todoId]);
      $this->onFinished();
    };
    $this->addSubmit('cancel','zrušit')
      ->setValidationScope([$todoId])
      ->onClick[]=function(){
      $this->onCancel();
    };
  }

  /**
   * @param Todo|array|object $values
   * @param bool $erase
   * @return $this
   */
  public function setDefaults($values, bool $erase = false):self {
    if ($values instanceof Todo){
      $valuesArr = [
        'todoId'=>$values->todoId,
        'title'=>$values->title,
        'description'=>$values->description
      ];
      parent::setDefaults($valuesArr, $erase);
    }else{
      parent::setDefaults($values, $erase);
    }
    return $this;
  }

}