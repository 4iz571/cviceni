<?php

namespace App\Model\Repositories;

use App\Model\Entities\Todo;

/**
 * Class TodoRepository - repozitář pro ukládání jednotlivých úkolů
 * @package App\Model\Repositories
 */
class TodoRepository extends BaseRepository{

  /**
   * Metoda pro nalezení úkolů podle tagu a stavu
   * @param int|null $tagId
   * @param bool|null $completed
   * @param int|null $offset
   * @param int|null $limit
   * @return Todo[]
   */
  public function findAllByTagAndState(?int $tagId = null, ?bool $completed = null, ?int $offset = null, ?int $limit = null):array {
    $query = $this->connection->select('*')->from($this->getTable());

    #region filtrování podle tagu
    if ($tagId){
      //pokud je zadané požadované ID tagu, najdeme ho v navázané tabulce
      $query->where('todo_id IN (SELECT todo_id FROM todo_tag WHERE tag_id=?)',$tagId); //místo ? bychom tu mohli mít také %s či %i
    }
    #endregion

    #region filtrování podle completed
    if ($completed!==null){
      //pokud je zadaný požadovaný stav, budeme podle něj filtrovat
      $query->where(['completed'=>$completed]);
    }
    #endregion

    #region řazení
    //necháme si úkoly seřadit podle stavu a deadline
    $query->orderBy('completed');
    $query->orderBy('%n IS NOT NULL','deadline');//%n označuje název sloupce
    $query->orderBy('deadline');
    #endregion

    //vytvoření entit
    return $this->createEntities($query->fetchAll($offset, $limit));
  }

  /**
   * Metoda pro nalezení počtu úkolů podle tagu a stavu
   * @param int|null $tagId
   * @param bool|null $completed
   * @return int
   */
  public function findCountByTagAndState(?int $tagId = null,?bool  $completed = null):int {
    $query = $this->connection->select('count(*) as pocet')->from($this->getTable());

    #region filtrování podle tagu
    if ($tagId){
      //pokud je zadané požadované ID tagu, najdeme ho v navázané tabulce
      $query->where('todo_id IN (SELECT todo_id FROM todo_tag WHERE tag_id=?)',$tagId); //místo ? bychom tu mohli mít také %s či %i
    }
    #endregion

    #region filtrování podle completed
    if ($completed!==null){
      //pokud je zadaný požadovaný stav, budeme podle něj filtrovat
      $query->where(['completed'=>$completed]);
    }
    #endregion

    //vrácení konkrétního počtu
    return $query->fetchSingle();
  }

}