<?php

namespace App\Components\TodoEditForm;

use App\Model\Entities\Todo;
use App\Model\Facades\TagsFacade;
use App\Model\Facades\TodosFacade;
use Nette;
use Nette\Application\UI\Form;
use Nette\SmartObject;

/**
 * Class TodoEditForm
 * @package App\Components\TodoEditForm
 *
 * @method onFinished(string $message = '')
 * @method onFailed(string $message = '')
 * @method onCancel()
 */
class TodoEditForm extends Form{

  use SmartObject;

  /** @var callable[] $onFinished */
  public array $onFinished = [];
  /** @var callable[] $onFailed */
  public array $onFailed = [];
  /** @var callable[] $onCancel */
  public array $onCancel = [];
  private TodosFacade $todosFacade;
  private TagsFacade $tagsFacade;

  public function __construct(TodosFacade $todosFacade, TagsFacade $tagsFacade, Nette\ComponentModel\IContainer $parent = null, string $name = null){
    parent::__construct($parent, $name);
    $this->todosFacade=$todosFacade;
    $this->tagsFacade=$tagsFacade;
    $this->createSubcomponents();
  }

  private function createSubcomponents():void {
    $todoId=$this->addHidden('todoId');
    $this->addText('title','Název úkolu:')
      ->setRequired('Vyplňte název úkolu');

    $this->addText('deadline','Deadline:')
      ->setHtmlType('date')
      ->setRequired(false)
      ->setNullable(true)
      ->addRule(function(Nette\Forms\Controls\TextInput $input){
        if (!empty($input->value)){
          return preg_match('/^20[0-9]{2}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/',$input->value);
        }else{
          return true;
        }
      },'Zadejte platné datum, nebo ponechte toto pole prázdné.');

    #region vytvoření pole s tagy uloženými v databázi a vytvoření checkboxlistu
    $tagsArr=[];
    $tags=$this->tagsFacade->findTags();
    if (!empty($tags)){
      foreach ($tags as $tag){
        $tagsArr[$tag->tagId]=$tag->title;
      }
    }
    $this->addCheckboxList('tags','Tagy:',$tagsArr)
      ->setRequired(false);
    #endregion

    $this->addTextArea('description','Popis:')
      ->setRequired(false);
    $this->addSubmit('save','uložit')->onClick[]=function(){
      $values = $this->getValues('array');
      if (!empty($values['todoId'])){
        //mám zadané ID úkolu
        try{
          $todo = $this->todosFacade->getTodo($values['todoId']);
        }catch (\Exception $e){
          $this->onFailed('úkol nebyl nalezen');
          return;
        }
      }else{
        $todo=new Todo();
      }
      $todo->title=$values['title'];
      $todo->description=$values['description'];

      //uložení datumu
      if ($values['deadline']){
        $todo->deadline=new \DateTimeImmutable($values['deadline']);
      }else{
        $todo->deadline=null;
      }

      $this->todosFacade->saveTodo($todo);
      #region uložení tagů
      $todo->removeAllTags();//odebereme vazby na všechny tagy
      if (!empty($values['tags'])){
        foreach ($values['tags'] as $tagId){
          try{
            $tag = $this->tagsFacade->getTag($tagId);
            $todo->addToTags($tag);
          }catch (\Exception $e){/*neexistující tag prostě nepřidáme => chybu ignorujeme*/}
        }
      }
      $this->todosFacade->saveTodo($todo);//znovuuložením úkolu se do DB uloží vazby na tagy
      #endregion
      $this->setValues(['todoId'=>$todo->todoId]);
      $this->onFinished();
    };
    $this->addSubmit('cancel','zrušit')
      ->setValidationScope([$todoId])
      ->onClick[]=function(){
      $this->onCancel();
    };
  }

  /**
   * @param Todo|array|object $values
   * @param bool $erase
   * @return $this
   */
  public function setDefaults($values, bool $erase = false):self {
    if ($values instanceof Todo){
      $valuesArr = [
        'todoId'=>$values->todoId,
        'title'=>$values->title,
        'description'=>$values->description,
        'deadline'=>($values->deadline?$values->deadline->format('Y-m-d'):null),
        'tags'=>[]
      ];
      #region tagy
      if (!empty($values->tags)){
        foreach ($values->tags as $tag){
          $valuesArr['tags'][]=$tag->tagId;
        }
      }
      #endregion
      parent::setDefaults($valuesArr, $erase);
    }else{
      parent::setDefaults($values, $erase);
    }
    return $this;
  }

}