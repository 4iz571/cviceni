<?php

namespace App\Model\Repositories;

/**
 * Class TodoItemRepository
 * @package App\Model\Repositories
 */
class TodoItemRepository extends BaseRepository{

} 