<?php

namespace App\Model\Repositories;

/**
 * Class TagRepository - repozitář pro ukládání jednotlivých tagů
 * @package App\Model\Repositories
 */
class TagRepository extends BaseRepository{

}